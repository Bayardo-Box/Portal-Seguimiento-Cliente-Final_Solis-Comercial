/**
 * Cloudflare Pages Function · /api/gestion
 * Gestión compartida del tablero Win-Back (asesor asignado, estatus, notas).
 * Guarda la gestión que el equipo registra en el tablero.
 * Requiere un espacio KV vinculado con el nombre GESTION
 * (Pages → Settings → Bindings → KV namespace → Variable name: GESTION).
 *   GET    /api/gestion        → { docs: [{ id, data }] }
 *   PUT    /api/gestion/:id    → guarda el documento (JSON)
 *   DELETE /api/gestion/:id    → borra el documento
 */
import { exigeCodigo, json } from '../zoho.js';

const P = 'g:';

export async function onRequest({ request, env, params }) {
  if (!env.GESTION) return json({ error: 'Gestión compartida no configurada (falta el KV GESTION)' }, 501);
  const e = exigeCodigo(env, request); if (e) return json({ error: e.message }, e.status);
  const id = Array.isArray(params.id) ? params.id.join('/') : (params.id || '');

  if (request.method === 'GET' && !id) {
    const keys = []; let cursor;
    do { const l = await env.GESTION.list({ prefix: P, cursor }); keys.push(...l.keys.map(k => k.name)); cursor = l.list_complete ? null : l.cursor; } while (cursor);
    const docs = await Promise.all(keys.map(async k => ({ id: k.slice(P.length), data: JSON.parse((await env.GESTION.get(k)) || '{}') })));
    return json({ docs });
  }
  if (!/^[\w.:@\-]{1,200}$/.test(id)) return json({ error: 'id inválido' }, 400);
  if (request.method === 'PUT') {
    const data = await request.json().catch(() => null);
    if (!data || typeof data !== 'object' || JSON.stringify(data).length > 8000) return json({ error: 'datos inválidos' }, 400);
    await env.GESTION.put(P + id, JSON.stringify(data));
  } else if (request.method === 'DELETE') {
    await env.GESTION.delete(P + id);
  } else return json({ error: 'método no permitido' }, 405);
  return json({ ok: true });
}
