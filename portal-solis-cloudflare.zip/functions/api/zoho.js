/**
 * Cloudflare Pages Function · POST /api/zoho
 * ---------------------------------------------------------------------------
 * Servicio de datos de los tableros: lee Zoho Books y Zoho CRM.
 * Recibe { server, tool, input } —las mismas llamadas que ya hacen los
 * tableros— y responde { status, data } con la respuesta original de Zoho.
 *
 * Solo permite LECTURAS y solo las consultas que usan los tableros:
 *   Zoho Books: list_invoices, get_invoice  (sin datos de clientes)
 *   Zoho CRM:   executeCOQLQuery (módulos permitidos), getUsers
 * Los datos de CRM (con nombres, teléfonos e IMEI de clientes) exigen el
 * código de equipo ACCESO_EQUIPO, salvo que CRM_PUBLICO = true.
 *
 * Variables de entorno (Cloudflare Pages → Settings → Variables and Secrets):
 *   ZOHO_CLIENT_ID, ZOHO_CLIENT_SECRET, ZOHO_REFRESH_TOKEN   (Secret)
 *   ACCESO_EQUIPO   código que escribe el equipo para Win-Back y Cashback (Secret)
 *   ZOHO_ORG_ID     872034702 (opcional)      ZOHO_DC  com (opcional)
 */

export const ORG_DEFAULT = '872034702';

export function cfg(env) {
  const dc = env.ZOHO_DC || 'com';
  return {
    accounts: `https://accounts.zoho.${dc}`,
    books: `https://www.zohoapis.${dc}/books/v3`,
    crm: `https://www.zohoapis.${dc}/crm/v6`,
    org: env.ZOHO_ORG_ID || ORG_DEFAULT
  };
}

export function json(body, status = 200, extra = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra }
  });
}

/** Token de acceso de Zoho, reutilizado ~50 min para no exceder el límite de renovaciones. */
export async function zohoToken(env) {
  const faltan = ['ZOHO_CLIENT_ID', 'ZOHO_CLIENT_SECRET', 'ZOHO_REFRESH_TOKEN'].filter(k => !env[k]);
  if (faltan.length) throw httpError(500, 'Faltan variables de entorno en Cloudflare: ' + faltan.join(', '));
  const cache = caches.default;
  const key = new Request('https://cache.local/zoho-token/' + (await sha(env.ZOHO_REFRESH_TOKEN)));
  const hit = await cache.match(key);
  if (hit) return (await hit.json()).t;
  const c = cfg(env);
  const q = new URLSearchParams({ refresh_token: env.ZOHO_REFRESH_TOKEN, client_id: env.ZOHO_CLIENT_ID, client_secret: env.ZOHO_CLIENT_SECRET, grant_type: 'refresh_token' });
  const r = await fetch(`${c.accounts}/oauth/v2/token?${q}`, { method: 'POST' });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.access_token) throw httpError(502, 'Zoho no entregó el token de acceso (' + (j.error || r.status) + ')');
  const ttl = Math.max(60, Math.min(3000, (Number(j.expires_in) || 3600) - 600));
  await cache.put(key, new Response(JSON.stringify({ t: j.access_token }), { headers: { 'Cache-Control': `max-age=${ttl}` } }));
  return j.access_token;
}

/** Código de equipo para los datos con información de clientes (Win-Back y Cashback). */
export function exigeCodigo(env, request) {
  if (String(env.CRM_PUBLICO).toLowerCase() === 'true') return null;
  if (!env.ACCESO_EQUIPO) return httpError(403, 'Falta configurar ACCESO_EQUIPO en Cloudflare para ver datos de clientes.');
  const dado = request.headers.get('X-Acceso') || '';
  if (!igual(dado, String(env.ACCESO_EQUIPO))) return httpError(401, 'Código de equipo requerido');
  return null;
}

export function httpError(status, message) { const e = new Error(message); e.status = status; return e; }

export async function sha(s) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(s)));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function igual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

/* ------------------------------------------------------------------ Ruta */
const CRM_MODULOS = ['CustomModule5001', 'Contacts', 'Cash_Back', 'Deals'];
const BOOKS_PARAMS = ['date', 'date_start', 'date_end', 'date_before', 'date_after', 'status', 'page', 'per_page', 'response_option', 'sort_column', 'sort_order', 'filter_by'];
const QUITAR_BOOKS = ['customer_name', 'customer_id', 'company_name', 'email', 'phone', 'mobile', 'billing_address', 'shipping_address', 'contact_persons', 'contact_persons_details',
  'invoice_url', 'zcrm_potential_name', 'customer_custom_fields', 'notes', 'terms', 'documents', 'attachment_name', 'reference_number', 'customer_default_billing_address', 'gst_no', 'tax_reg_no'];

export async function onRequestPost({ request, env, waitUntil }) {
  let body;
  try { body = await request.json(); } catch { return json({ status: 'failure', data: { message: 'Solicitud inválida' } }, 400); }
  const { server, tool, input = {} } = body || {};
  try {
    const plan = planificar(server, tool, input, env);
    if (plan.crm) { const e = exigeCodigo(env, request); if (e) throw e; }

    const cache = caches.default;
    const key = new Request('https://cache.local/zoho/' + (await sha(JSON.stringify([server, tool, input]))));
    const fresco = request.headers.get('X-Refresh') === '1';
    if (!fresco) { const hit = await cache.match(key); if (hit) return new Response(hit.body, { headers: { 'Content-Type': 'application/json; charset=utf-8', 'X-Cache': 'HIT', 'X-Stored-At': hit.headers.get('X-Stored-At') || '' } }); }

    const token = await zohoToken(env);
    const r = await fetch(plan.url, { method: plan.method, headers: { Authorization: `Zoho-oauthtoken ${token}`, ...(plan.body ? { 'Content-Type': 'application/json' } : {}) }, body: plan.body });
    let data = r.status === 204 ? { data: [], info: { count: 0, more_records: false } } : await r.json().catch(() => ({}));
    if (!r.ok || (plan.books && data.code !== 0)) {
      return json({ status: 'failure', data: { code: data.code, message: data.message || ('Zoho respondió ' + r.status) } }, r.status === 429 ? 429 : 200);
    }
    if (plan.books) data = limpiarBooks(data);
    if (tool === 'getUsers') data = { users: (data.users || []).map(u => ({ id: u.id, full_name: u.full_name, first_name: u.first_name, last_name: u.last_name, status: u.status, role: u.role && { name: u.role.name } })) , info: data.info };

    const out = JSON.stringify({ status: 'success', data });
    const ahora = new Date().toISOString();
    waitUntil(cache.put(key, new Response(out, { headers: { 'Content-Type': 'application/json', 'Cache-Control': `max-age=${plan.ttl}`, 'X-Stored-At': ahora } })));
    return new Response(out, { headers: { 'Content-Type': 'application/json; charset=utf-8', 'X-Cache': 'MISS', 'X-Stored-At': ahora } });
  } catch (e) {
    const status = e.status || 502;
    return json({ status: 'failure', data: { message: e.message || 'Error' } }, status);
  }
}

function planificar(server, tool, input, env) {
  const c = cfg(env);
  const hoy = new Date(Date.now() - 6 * 3600e3).toISOString().slice(0, 10);
  if (server === 'Zoho Books') {
    const qp = (input && input.query_params) || {};
    const q = new URLSearchParams({ organization_id: c.org });
    for (const k of BOOKS_PARAMS) if (qp[k] != null && qp[k] !== '') q.set(k, String(qp[k]));
    if (tool === 'list_invoices') {
      const fin = qp.date || qp.date_end || qp.date_before || hoy;
      return { books: true, method: 'GET', url: `${c.books}/invoices?${q}`, ttl: fin < hoy ? 6 * 3600 : 120 };
    }
    if (tool === 'get_invoice') {
      const id = String((input.path_variables || {}).invoice_id || '');
      if (!/^\d{5,25}$/.test(id)) throw httpError(400, 'invoice_id inválido');
      return { books: true, method: 'GET', url: `${c.books}/invoices/${id}?organization_id=${c.org}`, ttl: 6 * 3600 };
    }
  }
  if (server === 'Zoho CRM') {
    if (tool === 'executeCOQLQuery') {
      const sq = String(((input || {}).body || {}).select_query || '').trim();
      const m = /^select\s[\s\S]+?\sfrom\s+([A-Za-z0-9_]+)\b/i.exec(sq);
      if (!m || /;|\b(insert|update|delete|upsert|drop)\b/i.test(sq)) throw httpError(400, 'Consulta no permitida');
      if (!CRM_MODULOS.includes(m[1])) throw httpError(403, 'Módulo no permitido: ' + m[1]);
      return { crm: true, method: 'POST', url: `${c.crm}/coql`, body: JSON.stringify({ select_query: sq }), ttl: 180 };
    }
    if (tool === 'getUsers') {
      return { crm: true, method: 'GET', url: `${c.crm}/users?type=AllUsers&per_page=200`, ttl: 3600 };
    }
  }
  throw httpError(400, `Herramienta no permitida: ${server} · ${tool}`);
}

function limpiarBooks(d) {
  const limpia = o => { if (!o || typeof o !== 'object') return o; for (const k of QUITAR_BOOKS) delete o[k]; return o; };
  if (Array.isArray(d.invoices)) d.invoices.forEach(limpia);
  if (d.invoice) limpia(d.invoice);
  return d;
}
