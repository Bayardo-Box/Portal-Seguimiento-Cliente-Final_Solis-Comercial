/* =====================================================================
   Conexión pública de los tableros con Zoho
   ---------------------------------------------------------------------
   Ofrece a los tableros tres funciones (window.solis.use('mcp' | 'db' |
   'downloads')) conectadas al servicio del propio sitio en Cloudflare:
     · mcp.callTool(...)  →  POST /api/zoho
     · db (gestión)       →  /api/gestion
     · downloads.save()   →  descarga normal del navegador
   No pide cuentas ni inicio de sesión. Los tableros con datos de
   clientes piden un código de equipo, una sola vez por teléfono/PC.
   ===================================================================== */
(function () {
  'use strict';
  var API = '/api/zoho', GESTION = '/api/gestion', LLAVE = 'solis_acceso_equipo';

  function codigo() { try { return localStorage.getItem(LLAVE) || ''; } catch (e) { return ''; } }
  function guardarCodigo(c) { try { localStorage.setItem(LLAVE, c); } catch (e) {} }
  function borrarCodigo() { try { localStorage.removeItem(LLAVE); } catch (e) {} }

  /* ---------- Ventana para el código de equipo ---------- */
  var pidiendo = null;
  function pedirCodigo(mensaje) {
    if (pidiendo) return pidiendo;
    pidiendo = new Promise(function (resolve) {
      var fondo = document.createElement('div');
      fondo.setAttribute('role', 'dialog'); fondo.setAttribute('aria-modal', 'true');
      fondo.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif';
      fondo.innerHTML =
        '<form style="background:#fff;color:#0f172a;border-radius:16px;max-width:360px;width:100%;padding:22px;box-shadow:0 20px 50px rgba(0,0,0,.35)">' +
        '<div style="font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#c8161d;font-weight:700">Solís Comercial</div>' +
        '<h2 style="margin:6px 0 4px;font-size:20px">Código de equipo</h2>' +
        '<p style="margin:0 0 14px;font-size:14px;color:#475569">' + (mensaje || 'Este tablero muestra datos de clientes. Escribe el código del equipo de ventas.') + '</p>' +
        '<input type="password" inputmode="numeric" autocomplete="off" required style="width:100%;box-sizing:border-box;font-size:18px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:10px" aria-label="Código de equipo">' +
        '<button type="submit" style="margin-top:14px;width:100%;padding:11px;border:0;border-radius:10px;background:#c8161d;color:#fff;font-size:16px;font-weight:700;cursor:pointer">Entrar</button>' +
        '</form>';
      document.body.appendChild(fondo);
      var inp = fondo.querySelector('input');
      setTimeout(function () { inp.focus(); }, 50);
      fondo.querySelector('form').addEventListener('submit', function (ev) {
        ev.preventDefault();
        var c = inp.value.trim(); if (!c) return;
        guardarCodigo(c); fondo.remove(); pidiendo = null; resolve(c);
      });
    });
    return pidiendo;
  }

  function cabeceras(extra) {
    var h = { 'Content-Type': 'application/json', Accept: 'application/json' };
    var c = codigo(); if (c) h['X-Acceso'] = c;
    for (var k in (extra || {})) h[k] = extra[k];
    return h;
  }

  function errorDe(status, msg) {
    var e = new Error(msg || 'Error');
    e.code = status === 429 ? 'server_unavailable' : status >= 500 || status === 0 ? 'server_unavailable' : 'tool_error';
    e.retryable = status === 429 || status === 503 || status === 0;
    e.retryAfterMs = 2000;
    return e;
  }

  /* ---------- mcp.callTool ---------- */
  async function callTool(server, tool, input, opts) {
    var refresh = !!(opts && opts.cache && (opts.cache.refresh || opts.cache.staleTime === 0));
    for (var intento = 0; intento < 3; intento++) {
      var r;
      try {
        r = await fetch(API, { method: 'POST', headers: cabeceras(refresh ? { 'X-Refresh': '1' } : null), body: JSON.stringify({ server: server, tool: tool, input: input || {} }) });
      } catch (e) { throw errorDe(0, 'Sin conexión con el servicio de datos'); }
      if (r.status === 401) { borrarCodigo(); await pedirCodigo(intento ? 'El código no es correcto. Inténtalo de nuevo.' : null); continue; }
      var j = await r.json().catch(function () { return null; });
      if (!j) throw errorDe(r.status || 502, 'El servicio de datos no respondió');
      if (!r.ok && j.status === 'failure' && r.status !== 200) throw errorDe(r.status, (j.data && j.data.message) || ('Error ' + r.status));
      var stored = Date.parse(r.headers.get('X-Stored-At') || '') || Date.now();
      return { payload: j, cache: { storedAt: stored } };
    }
    throw errorDe(401, 'Código de equipo requerido');
  }

  /* ---------- db: gestión compartida (Win-Back) ---------- */
  async function pedirGestion(metodo, id, data) {
    for (var intento = 0; intento < 3; intento++) {
      var r = await fetch(GESTION + (id ? '/' + encodeURIComponent(id) : ''), { method: metodo, headers: cabeceras(), body: data ? JSON.stringify(data) : undefined });
      if (r.status === 401) { borrarCodigo(); await pedirCodigo(); continue; }
      if (r.status === 501) { var e1 = new Error('sin gestión'); e1.code = 'unavailable'; throw e1; }
      if (!r.ok) { var e = new Error('Error ' + r.status); e.code = r.status === 403 ? 'invalid_argument' : 'error'; throw e; }
      return r.json();
    }
    var e2 = new Error('Código requerido'); e2.code = 'invalid_argument'; throw e2;
  }
  async function crearDb() {
    try { await pedirGestion('GET'); } catch (e) { if (e.code === 'unavailable') return null; }
    var id = function (p) { return String(p).replace(/^gestion\//, ''); };
    return {
      doc: function (path) {
        return {
          set: function (data) { return pedirGestion('PUT', id(path), data); },
          delete: function () { return pedirGestion('DELETE', id(path)); }
        };
      },
      collection: function () {
        return {
          onSnapshot: function (cb, onErr) {
            var vivo = true;
            async function tick() {
              if (!vivo) return;
              try {
                var j = await pedirGestion('GET');
                cb({ docs: (j.docs || []).map(function (d) { return { id: d.id, data: function () { return d.data; } }; }) });
              } catch (e) { if (onErr) onErr(e); }
              if (vivo) setTimeout(tick, document.hidden ? 60000 : 20000);
            }
            tick();
            return function () { vivo = false; };
          }
        };
      }
    };
  }

  /* ---------- downloads ---------- */
  var downloads = {
    save: async function (o) {
      var data = o && o.data, blob;
      if (data instanceof Blob) blob = data;
      else if (data instanceof ArrayBuffer || ArrayBuffer.isView(data)) blob = new Blob([data]);
      else blob = new Blob([String(data == null ? '' : data)], { type: 'text/plain;charset=utf-8' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = (o && o.filename) || 'descarga';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      return { ok: true };
    }
  };

  var mcp = { callTool: callTool };
  var dbPromesa = null;
  window.solis = {
    use: function (nombre) {
      if (nombre === 'mcp') return Promise.resolve(mcp);
      if (nombre === 'downloads') return Promise.resolve(downloads);
      if (nombre === 'db') return dbPromesa || (dbPromesa = crearDb());
      return Promise.resolve(null);
    }
  };
  window.SolisConexion = { callTool: callTool, pedirCodigo: pedirCodigo };
})();
