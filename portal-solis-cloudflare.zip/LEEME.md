# Portal Solís Comercial · Cloudflare Pages

Sitio público: los vendedores lo abren desde un enlace y no necesitan ninguna cuenta.

```
index.html                     Portada (Hub Ejecutivo)
tableros/plan.html             Plan de Ventas Noviembre 2026
tableros/ventas.html           Dashboard de Ventas
tableros/winback.html          Win-Back · Recontacto de Clientes   (pide código de equipo)
tableros/cashback.html         Dashboard Cashback / Trade-in       (pide código de equipo)
tableros/conexion.js           Conexión de los tableros con el servicio de datos
tableros/motor.js / motor.css  Motor de Plan y Cashback
functions/api/zoho.js          Servicio de datos: lee Zoho con las credenciales guardadas en Cloudflare
functions/api/gestion/[[id]].js  Gestión compartida de Win-Back (asignación, estatus, notas)
```

## Configuración en Cloudflare Pages (una sola vez)

1. **Credenciales de Zoho** — en https://api-console.zoho.com crea un *Self Client* y genera un código con los permisos
   `ZohoBooks.invoices.READ,ZohoCRM.coql.READ,ZohoCRM.modules.READ,ZohoCRM.users.READ`; cámbialo por un *refresh token*.
2. **Variables** — Pages → tu proyecto → Settings → Variables and Secrets (tipo *Secret*):
   - `ZOHO_CLIENT_ID`, `ZOHO_CLIENT_SECRET`, `ZOHO_REFRESH_TOKEN`
   - `ACCESO_EQUIPO` → el código que escribirá el equipo para abrir Win-Back y Cashback (por ejemplo, 6 dígitos)
   - Opcionales: `ZOHO_ORG_ID` (872034702) y `ZOHO_DC` (com)
3. **Gestión compartida de Win-Back** — Workers & Pages → KV → crea un espacio (p. ej. `solis-gestion`) y vincúlalo en
   Pages → Settings → Bindings → KV namespace con el nombre de variable **`GESTION`**.
4. Vuelve a publicar (Deployments → Retry deployment).

## Seguridad

- El servicio solo permite **lecturas** y solo las consultas que usan los tableros. No puede crear, modificar ni borrar nada en Zoho.
- Las respuestas de Zoho Books llegan **sin datos de clientes** (nombre, correo, teléfono, direcciones).
- Win-Back y Cashback muestran nombres, teléfonos e IMEI de clientes: por eso piden `ACCESO_EQUIPO`.
  Para quitar el código (no recomendado) agrega la variable `CRM_PUBLICO = true`.
- Para cambiar el código, edita `ACCESO_EQUIPO` y vuelve a publicar: el equipo deberá escribir el nuevo código.
